/**
 * AWS Lambda: SOS Session Notifier
 * 
 * Triggered by DynamoDB Stream on SOSSession table (INSERT events).
 * 
 * Flow:
 * 1. Extract senderPhone + authorizedViewers from new SOS record
 * 2. For each viewer phone, look up the User table for FCM tokens
 * 3. Registered users → send FCM push via SNS Platform Application
 * 4. Unregistered users → send SMS fallback via SNS
 * 
 * Environment Variables:
 *   USER_TABLE_NAME   - DynamoDB User table name (e.g., "User-xxxx-dev")
 *   SNS_PLATFORM_ARN  - SNS Platform Application ARN for FCM
 *   SMS_SENDER_ID     - SNS SMS sender ID (e.g., "Suraksha")
 */

const { DynamoDBClient, BatchGetItemCommand } = require('@aws-sdk/client-dynamodb');
const { SNSClient, PublishCommand, CreatePlatformEndpointCommand } = require('@aws-sdk/client-sns');
const { unmarshall } = require('@aws-sdk/util-dynamodb');

const dynamodb = new DynamoDBClient({});
const sns = new SNSClient({});

const USER_TABLE = process.env.USER_TABLE_NAME || 'User-dev';
const SNS_PLATFORM_ARN = process.env.SNS_PLATFORM_ARN || '';
const SMS_SENDER_ID = process.env.SMS_SENDER_ID || 'Suraksha';

exports.handler = async (event) => {
  console.log('Received event:', JSON.stringify(event, null, 2));

  for (const record of event.Records) {
    // Only process INSERT events (new SOS sessions)
    if (record.eventName !== 'INSERT') continue;

    const newImage = unmarshall(record.dynamodb.NewImage);
    const {
      id: sessionId,
      phoneNumber: senderPhone,
      triggerType,
      authorizedViewers,
      latitude,
      longitude,
    } = newImage;

    if (!authorizedViewers || authorizedViewers.length === 0) {
      console.log('No authorizedViewers for session:', sessionId);
      continue;
    }

    console.log(`Processing SOS session ${sessionId} from ${senderPhone}, type: ${triggerType}`);
    console.log(`Authorized viewers: ${authorizedViewers.join(', ')}`);

    // ── Step 1: Batch lookup users by phone number ──
    const keys = authorizedViewers.map(phone => ({
      phoneNumber: { S: phone }
    }));

    // DynamoDB BatchGetItem has a 100-item limit, chunk if needed
    const chunks = [];
    for (let i = 0; i < keys.length; i += 100) {
      chunks.push(keys.slice(i, i + 100));
    }

    const registeredUsers = [];
    const allPhones = new Set(authorizedViewers);

    for (const chunk of chunks) {
      try {
        const result = await dynamodb.send(new BatchGetItemCommand({
          RequestItems: {
            [USER_TABLE]: { Keys: chunk }
          }
        }));

        const users = (result.Responses?.[USER_TABLE] || []).map(item => unmarshall(item));
        registeredUsers.push(...users);
        users.forEach(u => allPhones.delete(u.phoneNumber));
      } catch (err) {
        console.error('BatchGetItem error:', err);
      }
    }

    const unregisteredPhones = [...allPhones];
    console.log(`Registered: ${registeredUsers.length}, Unregistered: ${unregisteredPhones.length}`);

    // ── Step 2: Send FCM Push to registered users ──
    const title = triggerType === 'LOW_BATTERY'
      ? '🔋 Emergency: Low Battery!'
      : '🚨 SOS Emergency Alert!';
    const body = triggerType === 'LOW_BATTERY'
      ? `${senderPhone}'s phone battery is critically low. Tap to view their location.`
      : `${senderPhone} has triggered an SOS. Tap to view their location.`;

    const fcmPayload = {
      notification: { title, body },
      data: {
        type: 'SOS_ALERT',
        sessionId: sessionId,
        triggerType: triggerType || 'MANUAL',
        senderPhone: senderPhone,
        click_action: 'FLUTTER_NOTIFICATION_CLICK',
      }
    };

    for (const user of registeredUsers) {
      const tokens = user.fcmTokens || [];
      for (const token of tokens) {
        try {
          // Create platform endpoint for this token
          const endpointRes = await sns.send(new CreatePlatformEndpointCommand({
            PlatformApplicationArn: SNS_PLATFORM_ARN,
            Token: token,
          }));

          const endpointArn = endpointRes.EndpointArn;

          // Send push via SNS
          await sns.send(new PublishCommand({
            TargetArn: endpointArn,
            Message: JSON.stringify({
              GCM: JSON.stringify(fcmPayload),
            }),
            MessageStructure: 'json',
          }));

          console.log(`✅ Push sent to ${user.phoneNumber} (token: ${token.substring(0, 20)}...)`);
        } catch (err) {
          console.error(`❌ Push failed for ${user.phoneNumber}:`, err.message);
        }
      }
    }

    // ── Step 3: SMS fallback for unregistered contacts ──
    for (const phone of unregisteredPhones) {
      try {
        const smsMessage = triggerType === 'LOW_BATTERY'
          ? `🚨 Suraksha+ Alert: ${senderPhone}'s battery is critically low. Download the app to track them: https://suraksha.dev-vansh.in`
          : `🚨 Suraksha+ SOS: ${senderPhone} needs help! Location: https://suraksha.dev-vansh.in/?session=${sessionId}`;

        await sns.send(new PublishCommand({
          PhoneNumber: phone,
          Message: smsMessage,
          MessageAttributes: {
            'AWS.SNS.SMS.SenderID': {
              DataType: 'String',
              StringValue: SMS_SENDER_ID,
            },
            'AWS.SNS.SMS.SMSType': {
              DataType: 'String',
              StringValue: 'Transactional',
            },
          },
        }));

        console.log(`📱 SMS sent to unregistered contact: ${phone}`);
      } catch (err) {
        console.error(`❌ SMS failed for ${phone}:`, err.message);
      }
    }
  }

  return { statusCode: 200, body: 'Processed' };
};
